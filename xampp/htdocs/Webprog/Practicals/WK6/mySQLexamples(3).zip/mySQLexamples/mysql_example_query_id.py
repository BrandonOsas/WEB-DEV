import mysql.connector

animal_id = int (input ('Enter animal id: '))
args = (animal_id,)
conn = mysql.connector.connect(host='localhost',
                              database='webprog',
                              user='root',
                              password='secret')
if conn.is_connected():
   print('Connected to MySQL database')
   cursor = conn.cursor()
   cursor.execute("SELECT * FROM animals WHERE id = %s",args)
   row = cursor.fetchone()
   while row is not None:
       print(row)
       row = cursor.fetchone()
   cursor.close()
conn.close()
 
 
