#! /usr/local/bin/python3
import mysql.connector
 
""" Connect to MySQL database """
conn = mysql.connector.connect(host='localhost',
                              database='webprog',
                              user='root',
                              password='secret')
if conn.is_connected():
   print ('Content-type:text/html \n')
   print('<H1> Connected to MySQL database </H1>')
   cursor = conn.cursor()
   cursor.execute("SELECT * FROM animals")
   row = cursor.fetchone()
   while row is not None:
       print(row,'</br>')
       row = cursor.fetchone()
   cursor.close()
conn.close()
 
 
