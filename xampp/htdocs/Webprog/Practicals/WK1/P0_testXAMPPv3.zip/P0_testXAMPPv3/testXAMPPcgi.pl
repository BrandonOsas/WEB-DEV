#!"..\xampp\perl\bin\perl.exe"

  use CGI qw/:standard/; # load standard CGI routines
  
  print header(); # create the HTTP header
 
  $inFile = "testXAMPP.html";
  open (IN, $inFile) or die "Can't open input";
  while(<IN>) {print;}
  
