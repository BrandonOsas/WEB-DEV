#!/Python34/python

import math
print("Content-Type: text/html")    # HTML is following
print()   
print("<TITLE>CGI script output</TITLE>")
print("<H1>This is my first CGI script</H1>")
print("<H1>This is my first CGI script</H1>")
print("Hello, world!")

print("bye world!")



#https://docs.python.org/3/library/cgi.html 