#! /usr/local/bin/python3

text = 'I like oranges'
print ('Content-type:text/html \n')
print ('<html>')
print ('<head>')
print ('<title>Hello Word - First CGI Program</title>')
print ('</head>')
print ('<body>')
print ('<h1>Hello Word! This is my first CGI program</h1>')
print ('<p>I would like to mention that ', text, ' . Thanks. </p>')
print ('</body>')
print ('</html>')
