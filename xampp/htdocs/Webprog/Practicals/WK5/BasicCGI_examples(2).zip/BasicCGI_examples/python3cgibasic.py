#! /usr/local/bin/python3.5

print("Content-Type: text/plain;charset=utf-8")
print()

print("Hello World!")