import re

fh = open('test2_animals.txt')
search = r"rat"

for line in fh:
	if re.search(search, line, re.IGNORECASE) != None:
		print (line)



