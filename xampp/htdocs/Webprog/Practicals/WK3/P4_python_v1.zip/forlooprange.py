n = 100
sum = 0
for counter in range(1,n+1):
    sum = sum + counter
print("Sum of 1 until %d: %d" % (n,sum))
print("Average is ", sum//n)