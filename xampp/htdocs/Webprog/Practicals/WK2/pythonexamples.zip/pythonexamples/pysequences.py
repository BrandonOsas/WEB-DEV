#! /usr/bin/python

mystring = "Python under Linux is great"
mylist = ['a', 'b', 3, 4]    # list
mytuple = ('a', 'b', 3, 4)    # tuple
mymarks = {"webProg":80, "OOSD":70, "POC":68, "NOS": 50}   # sequence
myset = set("this is a book")

#list operations - check lecture slides
print(mylist)
mylist.insert(2,'c')
mylist.append(5)
print(mylist)

#typle operations - check lecture slides
print(mytuple[0])
print(mytuple[1])


#string operations - check lecture slides
print (mystring[::3])

#dictionary operations - check lecture slides
print(mymarks['webProg'])
print(mymarks.keys())
print(mymarks.values())

for key in mymarks.keys():
  print("Key: ", key, " Value: ", mymarks[key]) 

#set operations - check lecture slides
print(myset)


