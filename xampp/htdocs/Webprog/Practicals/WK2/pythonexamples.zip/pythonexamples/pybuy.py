#! /usr/bin/python 

import re
# You must create an input file

fh = open("shop.txt")

for line in fh:
  #replace e with z
  line = line.rstrip('\n')
  line = line.replace('e','z') 
  print(line)
fh.close()

print("*******************")
print("*** Another Way ***")
print("*******************")
print("****** Using ******")
print("**** re Module ****")
print("*******************")

fh = open("shop.txt")
for line in fh:
  line = re.sub('e','z',line)
  print(line.rstrip('\n'))  
fh.close()
  

print("*******************")
print("*** Another Way ***")
print("*******************")
print("****** Using ******")
print("**** read func ****")
print("*******************")

fh = open("shop.txt")
data = fh.read()	# no use of loop
data = data.replace('e','z')
print (data)
fh.close()