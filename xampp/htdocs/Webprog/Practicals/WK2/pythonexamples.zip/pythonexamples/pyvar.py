#! /usr/bin/python 

sweet = input("What sweet do you like?: ") #sweet = "chocolate"
presents = input("How many sweets would you like to have as present?: ") # presents = 12
print ("I like", sweet)
print ("How many? ", presents)
