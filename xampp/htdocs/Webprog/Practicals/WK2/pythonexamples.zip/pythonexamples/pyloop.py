#! /usr/bin/python 

for i in (0,3+1):
  print (i, "Hello")
 
for i in range(0,3+1):
  print (i, "Bye")

total = 100
while total > 0: 
    # get number from user
    print(total, " left")
    innum = int(input("Enter number : "))   
    total = total - innum
else:
    print ("total value became <= 0 i.e. ", total)


