#! /usr/bin/python 

line = input ("Enter some text")
print ("You gave " , len(line) , " characters")   #len() method returns number of characters in string
line = line.upper() # upper() method to convert string to uppercase 
					# more string methods: https://docs.python.org/3.4/library/stdtypes.html#string-methods
print ("In uppercase: ", line)
if len(line) > 5:
     print ("More than 5 characters")
  
  

