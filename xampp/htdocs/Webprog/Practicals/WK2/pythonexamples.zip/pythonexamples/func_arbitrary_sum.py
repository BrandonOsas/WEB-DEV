def arithmetic_sum(first, *more):
    return (first + sum(more))

print (arithmetic_sum(1,2))
print (arithmetic_sum(1,2,3))
print (arithmetic_sum(1,2,3,4))
print (arithmetic_sum(1,2,3,4,5))
print (arithmetic_sum(1,2,3,4,5,6))
